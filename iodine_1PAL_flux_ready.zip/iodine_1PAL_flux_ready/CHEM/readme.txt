
The subdirectory CHEM contains all programs related to the chemistry.
