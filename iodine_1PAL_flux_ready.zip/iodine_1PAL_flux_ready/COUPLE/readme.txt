CLIMA/COUPLE

This subdirectory contains the subroutines needed to "translate" the grids
from the photochemical and RRTM models to the climate model. 

