
This subdirectoty contains the subroutines that set up the initial conditions
in the code
