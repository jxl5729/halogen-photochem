
This subdirectory contains the subroutines that calculate the particles 
in the atmosphere